#include <iostream>
using namespace std;
int main(){
	//g++ -o spaceconverter spaceconveter.cpp
	int select;
	cout << "For celsius to fahrenheit, write 1 \n";
	cout << "For celsius to kelvin, write 2 \n";
	cout << "For fahrenheit to celsius, write 3 \n";
	cout << "For fahrenheit to kelvin, write 4 \n";
	cout << "For kelvin to celsius, write 5 \n";
	cout << "For kelvin to fahrenheit, write 6 \n";
	cin >> select;
	if(select == 1){
		int celsius;
	cout << "Enter celsius: \n";
		cin >> celsius;
		int answer1 = (celsius * 9) / 5 + 32;
		cout << answer1 ;
		cout << "Fahrenheit";
		int wait;
		cin >> wait;
	}
	else if(select == 2){
		int celsius;
		cout << "Enter celsius: \n";
		cin >> celsius;
		int answer2 = celsius + 273.15;
		cout << answer2;
		cout << "Kelvin";
		int wait2;
		cin >> wait2;
	}
	else if(select == 3){
		int fahrenheit;
		cout << "Enter Fahrenheit: \n";
		cin >> fahrenheit;
		int answer3 = 5/9 * (fahrenheit-32);
		cout << answer3;
		cout << " Celsius";
		int wait3;
		cin >> wait3;
	}
	
	else if(select == 4){
		int fahrenheit;
		cout << "Enter Fahrenheit: \n";
		cin >> fahrenheit;
		int answer4 = (fahrenheit - 32) / 5 + 273.15;
		cout << answer4;
		cout << " Kelvin";
		int wait4;
		cin >> wait4;
	}
	
	else if(select == 5){
		int kelvin;
		cout << "Enter Kelvin: \n";
		cin >> kelvin;
		int answer5 = kelvin - 273.15;
		cout << answer5;
		cout << " Celsius";
		int wait5;
		cin >> wait5;
	}
	
	else if(select == 6){
		int kelvin;
		cout << "Enter Kelvin: \n";
		cin >> kelvin;
		int answer6 = 9/5 * (kelvin - 273);
		cout << answer6;
		cout << " Fahrenheit";
		int wait6;
		cin >> wait6;
	}

}